name = "fuzzycmeans"
from fuzzycmeans.fuzzy_clustering import FCM
