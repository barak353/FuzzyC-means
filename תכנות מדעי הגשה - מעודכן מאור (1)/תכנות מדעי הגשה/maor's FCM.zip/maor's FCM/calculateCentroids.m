%calculate centroids
function [centroids] = calculateCentroids(points,weightsMatrix,centroids,numOfClusters,p,elements)
  for i = 1:numOfClusters
       centroids(i, :) = sum((points(:, :).*repmat(weightsMatrix(i, :)'.^p, 1, elements)), 1)./sum(weightsMatrix(i, :).^p);  
  end
end