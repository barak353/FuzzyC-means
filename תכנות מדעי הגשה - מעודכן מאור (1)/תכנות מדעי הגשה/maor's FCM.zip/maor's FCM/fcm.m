
function [centroids,iterations ,weightsMatrix] = fcm(numOfClusters, points, p, distance, maxIterations, delta)
[numOfPoints, elements] = size(points);
centroids = rand([numOfClusters, elements]);
weightsMatrix = rand([numOfClusters, numOfPoints]);


for j = 1:numOfPoints
      weightsMatrix(:, j) = weightsMatrix(:, j)./(sum(weightsMatrix(:, j))+0.0001);      
end  
%initialize centroids
centroids = calculateCentroids(points,weightsMatrix,centroids,numOfClusters,p,elements);
%saves centroids for comaparison after updating them
oldCentroids = centroids;
%define bigger differnce value from delta to enter the while loop
diff = 1e4;
%initiliaze iterations counter
iterations = 0;
%updates the weights matrix
while  (iterations<maxIterations || diff>delta)
    for i = 1:numOfClusters
      for j = 1:numOfPoints
          den = sum((distance(points(j, :), centroids(i, :))./distance(points(j, :), centroids)).^(2/(p-1)));
          if den == 0
             den = 1/0.001; 
          end  
          weightsMatrix(i, j) = 1/den;
      end
    end

    %end of weightsMatrix update iteration    
    iterations=iterations+1;   
    %update centroids after weightsMatrix update
    centroids = calculateCentroids(points,weightsMatrix,centroids,numOfClusters,p,elements);
    updatedCentroids = centroids;
    diff = max(max(abs(updatedCentroids-oldCentroids)));
    oldCentroids = centroids;

end


end