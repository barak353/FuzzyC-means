%calculates euclidean distance between x and y
function [dis] = distanceFunc(x, y)
           dis = sum((x-y).^2, 2);
           dis = sqrt(dis);
end