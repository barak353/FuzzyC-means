clear all
clc
addpath('fcm')
load('mat1.mat','mat1')

maxIterations = 50;%max iterations limit for the algorithem updates
distFunc = @distanceFunc;%loading distanceFunc from 'distanceFunc.m'
points = mat1;%loading points from mat1.mat
p = 6;%weightsMatrix update power


%3 runs options , need to run 1 each option at a time , otherwise the tic
%toc counter doesn't makes sense

tic
[centroids3,iterations3,weightsMatrix3] = fcm(6, points, p, distFunc, maxIterations, 1e-3);
toc

tic
[centroids1,iterations1,weightsMatrix1] = fcm(3, points, p, distFunc, maxIterations, 1e-3);
toc

tic
[centroids2,iterations2,weightsMatrix2] = fcm(5, points, p, distFunc, maxIterations, 1e-3);
toc
